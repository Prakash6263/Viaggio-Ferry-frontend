import React from 'react'
import Header from '../components/layout/Header'
import {Sidebar} from '../components/layout/Sidebar'
import { Link } from 'react-router-dom'
const EditCompanyProfile = () => {
  return (
    <>
          <div className="main-wrapper">
            <Header />
            <Sidebar />
      
            <div className="page-wrapper">
            <div className="content container-fluid">
        {/* Back Button */}
        <div className="mb-3">
          <Link to="/company/settings/company-profile" className="btn btn-turquoise">
            <i className="bi bi-arrow-left" /> Back to List
          </Link>
        </div>
        <div className="row g-4">
          {/* Basic Company Info */}
          <div className="col-md-12">
            <div className="card flex-fill">
              <div className="card-header">
                <div className="d-flex justify-content-between align-items-center">
                  <h5 className="card-title">Basic Company Information</h5>
                </div>
              </div>
              <div className="card-body">
                <div className="mb-3">
                  <label className="form-label">Company Name</label>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Enter company name"
                  />
                </div>
                <div className="mb-3">
                  <label className="form-label">Registration Number</label>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Enter registration number"
                  />
                </div>
                <div className="mb-3">
                  <label className="form-label">Logo</label>
                  <input type="file" className="form-control" />
                </div>
                <div className="mb-3">
                  <label className="form-label">Date Established</label>
                  <input type="date" className="form-control" />
                </div>
              </div>
            </div>
          </div>
          {/* Contact Details */}
          <div className="col-md-12">
            <div className="card flex-fill">
              <div className="card-header">
                <div className="d-flex justify-content-between align-items-center">
                  <h5 className="card-title">Contact Details</h5>
                </div>
              </div>
              <div className="card-body">
                <div className="mb-3">
                  <label className="form-label">Address</label>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Street Address"
                  />
                </div>
                <div className="row">
                  <div className="col-md-6 mb-3">
                    <label className="form-label">City</label>
                    <input type="text" className="form-control" placeholder="City" />
                  </div>
                  <div className="col-md-6 mb-3">
                    <label className="form-label">Country</label>
                    <input
                      type="text"
                      className="form-control"
                      placeholder="Country"
                    />
                  </div>
                </div>
                <div className="mb-3">
                  <label className="form-label">Postal Code</label>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Postal Code"
                  />
                </div>
                <div className="mb-3">
                  <label className="form-label">Main Phone Number</label>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="+1 234 567 890"
                  />
                </div>
                <div className="mb-3">
                  <label className="form-label">Email Address</label>
                  <input
                    type="email"
                    className="form-control"
                    placeholder="example@email.com"
                  />
                </div>
                <div className="mb-3">
                  <label className="form-label">Website</label>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="https://"
                  />
                </div>
              </div>
            </div>
          </div>
          {/* Operational Details */}
          <div className="col-md-12">
            <div className="card flex-fill">
              <div className="card-header">
                <div className="d-flex justify-content-between align-items-center">
                  <h5 className="card-title">Operational Details</h5>
                </div>
              </div>
              <div className="card-body">
                <div className="mb-3">
                  <label className="form-label">Default Currency</label>
                  <select className="form-select">
                    <option>USD</option>
                    <option>EUR</option>
                    <option>GBP</option>
                  </select>
                </div>
                <div className="mb-3">
                  <label className="form-label">Operating Ports</label>
                  <select className="form-select" multiple="">
                    <option>Port A</option>
                    <option>Port B</option>
                    <option>Port C</option>
                    <option>Port D</option>
                  </select>
                </div>
                <div className="mb-3">
                  <label className="form-label">Working Hours</label>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Mon-Fri, 9am-5pm"
                  />
                </div>
              </div>
            </div>
          </div>
          {/* About Us */}
          <div className="col-md-12">
            <div className="card flex-fill">
              <div className="card-header">
                <div className="d-flex justify-content-between align-items-center">
                  <h5 className="card-title">About Us</h5>
                </div>
              </div>
              <div className="card-body">
                <div className="mb-3">
                  <label className="form-label">Who We Are</label>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Description"
                  />
                </div>
                <div className="mb-3">
                  <label className="form-label">Vision</label>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Our vision"
                  />
                </div>
                <div className="mb-3">
                  <label className="form-label">Mission</label>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Our mission"
                  />
                </div>
                <div className="mb-3">
                  <label className="form-label">Purpose</label>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Our purpose"
                  />
                </div>
              </div>
            </div>
          </div>
          {/* Social Network Links */}
          <div className="col-md-12">
            <div className="card flex-fill">
              <div className="card-header">
                <div className="d-flex justify-content-between align-items-center">
                  <h5 className="card-title">Social Network Links</h5>
                </div>
              </div>
              <div className="card-body">
                <div className="mb-3">
                  <label className="form-label">Facebook</label>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Facebook URL"
                  />
                </div>
                <div className="mb-3">
                  <label className="form-label">Instagram</label>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Instagram URL"
                  />
                </div>
                <div className="mb-3">
                  <label className="form-label">WhatsApp</label>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="WhatsApp Number"
                  />
                </div>
                <div className="mb-3">
                  <label className="form-label">LinkedIn</label>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="LinkedIn Profile"
                  />
                </div>
                <div className="mb-3">
                  <label className="form-label">Skype</label>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Skype ID"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
        {/* Save Button */}
        <div className="mt-4">
          <button className="btn btn-turquoise">Save Company Profile</button>
        </div>
      </div>
      
            </div>
      
          
          </div>
    </>
  )
}

export default EditCompanyProfile
