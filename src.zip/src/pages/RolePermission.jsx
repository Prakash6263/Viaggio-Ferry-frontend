"use client"

import { useEffect, useState } from "react"
import { Link } from "react-router-dom"
import Header from "../components/layout/Header"
import { Sidebar } from "../components/layout/Sidebar"
import { PageWrapper } from "../components/layout/PageWrapper"
import { accessGroupsApi } from "../api/accessGroupsApi"

export default function RolePermission() {
  const [groups, setGroups] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [pagination, setPagination] = useState({ page: 1, limit: 10, total: 0, pages: 0 })

  useEffect(() => {
    fetchAccessGroups()
  }, [pagination.page])

  const fetchAccessGroups = async () => {
    try {
      setLoading(true)
      const response = await accessGroupsApi.getAccessGroupsList(pagination.page, pagination.limit)
      setGroups(response.data || [])
      setPagination(response.pagination || {})
      setError(null)
    } catch (err) {
      setError(err.message || "Failed to fetch access groups")
      console.error("Error fetching access groups:", err)
    } finally {
      setLoading(false)
    }
  }

  const handleDelete = async (groupId) => {
    if (window.confirm("Are you sure you want to delete this access group?")) {
      try {
        await accessGroupsApi.deleteAccessGroup(groupId)
        fetchAccessGroups()
      } catch (err) {
        alert("Failed to delete access group: " + err.message)
      }
    }
  }

  const handleStatusToggle = async (group) => {
    try {
      await accessGroupsApi.updateAccessGroup(group._id, {
        ...group,
        isActive: !group.isActive,
      })
      fetchAccessGroups()
    } catch (err) {
      alert("Failed to update status: " + err.message)
    }
  }

  const getLayerBadgeClass = (layer) => {
    const layerMap = {
      company: "bg-primary",
      "marine-agent": "bg-info",
      "commercial-agent": "bg-success",
      "selling-agent": "bg-warning text-dark",
    }
    return layerMap[layer] || "bg-secondary"
  }

  return (
    <div className="main-wrapper">
      <Header />
      <Sidebar />

      <PageWrapper>
        <div className="content container-fluid">
          {/* Page Header */}
          <div className="page-header">
            <div className="content-page-header">
              <h5>Access Rights Group Management</h5>

              <div className="list-btn" style={{ justifySelf: "end" }}>
                <ul className="filter-list">
                  <li>
                    <Link className="btn btn-turquoise" to="/company/settings/add-group-permission">
                      <i className="fa fa-plus-circle me-2" aria-hidden="true"></i>
                      Add New Group Permission
                    </Link>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          {/* /Page Header */}

          <div className="row">
            <div className="col-sm-12">
              <div className="card-table card p-2">
                <div className="card-body">
                  {/* Inline CSS block from HTML, kept for visual parity */}
                  <style>
                    {`
                      .status-label {
                        display: inline-block;
                        min-width: 40px;
                        text-align: center;
                        padding: 0.25rem 0.5rem;
                        border-radius: 0.25rem;
                        font-weight: 500;
                      }

                      .status-yes {
                        background-color: #ffc107;
                        color: #212529;
                      }

                      .form-switch .form-check-input {
                        width: 45px;
                        height: 22px;
                        cursor: pointer;
                      }

                      .form-switch .form-check-input:checked {
                        background-color: #0d6efd;
                        border-color: #0d6efd;
                      }
                    `}
                  </style>

                  {loading && (
                    <div className="text-center py-5">
                      <div className="spinner-border" role="status">
                        <span className="visually-hidden">Loading...</span>
                      </div>
                    </div>
                  )}

                  {error && (
                    <div className="alert alert-danger alert-dismissible fade show" role="alert">
                      {error}
                      <button type="button" className="btn-close" onClick={() => setError(null)}></button>
                    </div>
                  )}

                  {!loading && !error && (
                    <div className="table-responsive">
                      <table id="example" className="table table-striped" style={{ width: "100%" }}>
                        <thead>
                          <tr>
                            <th>Group Name</th>
                            <th>Group Code</th>
                            <th>Module Name</th>
                            <th>Layer</th>
                            <th>Status</th>
                            <th>Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                          {groups.length > 0 ? (
                            groups.map((group) => (
                              <tr key={group._id}>
                                <td>{group.groupName}</td>
                                <td>{group.groupCode}</td>
                                <td>{group.moduleCode}</td>
                                <td>
                                  <span className={`badge ${getLayerBadgeClass(group.layer)}`}>
                                    {group.layer.replace("-", " ").charAt(0).toUpperCase() +
                                      group.layer.slice(1).replace("-", " ")}
                                  </span>
                                </td>
                                <td>
                                  <label className="status-toggle">
                                    <input
                                      type="checkbox"
                                      checked={group.isActive}
                                      onChange={() => handleStatusToggle(group)}
                                    />
                                    <span className="slider"></span>
                                  </label>
                                </td>
                                <td className="action-buttons">
                                  <Link
                                    to={`/company/settings/add-group-permission?id=${group._id}`}
                                    className="btn btn-sm btn-outline-primary"
                                  >
                                    <i className="bi bi-pencil"></i>
                                  </Link>
                                  <button
                                    className="btn btn-sm btn-outline-danger"
                                    onClick={() => handleDelete(group._id)}
                                  >
                                    <i className="bi bi-trash"></i>
                                  </button>
                                </td>
                              </tr>
                            ))
                          ) : (
                            <tr>
                              <td colSpan="6" className="text-center py-5">
                                <p className="text-muted">No access groups found</p>
                              </td>
                            </tr>
                          )}
                        </tbody>
                      </table>
                    </div>
                  )}
                  {/* end table-responsive */}
                </div>
              </div>
            </div>
          </div>
        </div>
      </PageWrapper>
    </div>
  )
}
