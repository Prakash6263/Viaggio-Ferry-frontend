import { usePermissions } from "../hooks/usePermissions"

/**
 * Can Component - Enterprise-grade Permission Guard
 *
 * Provides clean, declarative permission-based UI rendering.
 * Replaces boilerplate permission checks throughout your pages.
 *
 * Usage:
 *  <Can action="create">
 *    <Button>Add New</Button>
 *  </Can>
 *
 *  <Can action="delete" fallback={<span>No access</span>}>
 *    <Button>Delete</Button>
 *  </Can>
 *
 * Props:
 *  - action: "read" | "create" | "update" | "delete" (required)
 *  - children: JSX to render if permitted (required)
 *  - fallback: JSX to render if NOT permitted (optional, default: null)
 *
 * Notes:
 *  - This is UX-only. Backend still enforces actual security.
 *  - Works with both company and user roles
 *  - Automatically handles missing permissions gracefully
 */
export default function Can({ action, children, fallback = null }) {
  const permissions = usePermissions()

  // If no permissions object (edge case), show fallback
  if (!permissions) return fallback

  // Map action to permission key
  const allowed = permissions[action] === true

  // Render children if allowed, otherwise render fallback
  return allowed ? children : fallback
}
