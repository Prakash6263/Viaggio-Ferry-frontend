"use client"

import { useMemo, useState, useEffect } from "react"
import { partnerApi } from "../../api/partnerApi"
import { usersApi } from "../../api/usersApi"

export default function AddUserForm() {
  // ---- STATE
  const [tab, setTab] = useState("profile") // 'profile' | 'access'
  const [form, setForm] = useState({
    fullName: "",
    email: "",
    position: "",
    partnerId: null,
    isSalesman: false,
    remarks: "",
  })

  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [partners, setPartners] = useState([])
  const [partnersLoading, setPartnersLoading] = useState(false)

  const [moduleAccess, setModuleAccess] = useState({}) // { moduleCode: accessGroupId }
  const [accessGroupsByModule, setAccessGroupsByModule] = useState({}) // { moduleCode: [accessGroups] }
  const [accessGroupsLoading, setAccessGroupsLoading] = useState({})

  // ---- CONSTANTS (layer mapping based on partner selection)
  const agentLayerMap = useMemo(
    () => ({
      company: { type: "Company", layer: "company" },
      marine: { type: "Marine", layer: "marine" },
      commercial: { type: "Commercial", layer: "commercial" },
      selling: { type: "Selling", layer: "selling" },
    }),
    [],
  )

  const modules = useMemo(
    () => [
      { code: "settings", name: "Settings" },
      { code: "administration", name: "Administration" },
      { code: "ship-trips", name: "Ship & Trips" },
      { code: "partners-management", name: "Partners Management" },
      { code: "sales-bookings", name: "Sales & Bookings" },
      { code: "checkin-boardings", name: "Check-in & Boardings" },
      { code: "finance", name: "Finance" },
    ],
    [],
  )

  // Fetch partners on component mount
  useEffect(() => {
    fetchPartners()
  }, [])

  useEffect(() => {
    if (form.partnerId) {
      fetchAccessGroupsForLayer()
    } else {
      setAccessGroupsByModule({})
      setModuleAccess({})
    }
  }, [form.partnerId])

  const fetchPartners = async () => {
    try {
      setPartnersLoading(true)
      const response = await partnerApi.getPartnersList()
      // Transform partners into layered structure including selling partners
      const groupedPartners = {
        company: [],
        marine: [],
        commercial: [],
        selling: [],
      }

      if (response.data && Array.isArray(response.data)) {
        response.data.forEach((partner) => {
          const partnerLayer = partner.layer?.toLowerCase() || partner.type?.toLowerCase() || "commercial"
          if (groupedPartners[partnerLayer] !== undefined) {
            groupedPartners[partnerLayer].push(partner)
          }
        })
      }

      setPartners(groupedPartners)
      setError(null)
    } catch (err) {
      console.error("Error fetching partners:", err)
      setError("Failed to load partners")
    } finally {
      setPartnersLoading(false)
    }
  }

  const fetchAccessGroupsForLayer = async () => {
    const selectedLayer = form.partnerId
    const layerInfo = agentLayerMap[selectedLayer]
    if (!layerInfo) return

    try {
      const groupedAccessGroups = {}

      for (const module of modules) {
        try {
          setAccessGroupsLoading((prev) => ({ ...prev, [module.code]: true }))
          const response = await usersApi.getAccessGroupsByModuleLayer(module.code, layerInfo.layer)
          groupedAccessGroups[module.code] = response.data?.accessGroups || []
        } catch (err) {
          console.error(`Error fetching access groups for ${module.code}:`, err)
          groupedAccessGroups[module.code] = []
        } finally {
          setAccessGroupsLoading((prev) => ({ ...prev, [module.code]: false }))
        }
      }

      setAccessGroupsByModule(groupedAccessGroups)
      setError(null)
    } catch (err) {
      console.error("Error fetching access groups:", err)
      setError("Failed to load access groups")
    }
  }

  const layerInfo = form.partnerId ? agentLayerMap[form.partnerId] : null

  const onChange = (e) => {
    const { name, value, type, checked } = e.target
    setForm((s) => ({ ...s, [name]: type === "checkbox" ? checked : value }))
  }

  const onSelectAccess = (moduleCode, value) => {
    setModuleAccess((s) => ({ ...s, [moduleCode]: value }))
  }

  const onSubmit = async (e) => {
    e.preventDefault()

    try {
      setLoading(true)
      setError(null)

      // Build moduleAccess array in the format expected by API
      const moduleAccessArray = Object.entries(moduleAccess)
        .filter(([_, accessGroupId]) => accessGroupId) // Only include selected items
        .map(([moduleCode, accessGroupId]) => ({
          moduleCode,
          accessGroupId,
        }))

      const payload = {
        fullName: form.fullName,
        email: form.email,
        position: form.position,
        layer: form.partnerId,
        isSalesman: form.isSalesman,
        partnerId: form.partnerId === "company" ? null : null,
        remarks: form.remarks,
        moduleAccess: moduleAccessArray,
      }

      const response = await usersApi.createUser(payload)

      // Success feedback
      alert("User created successfully!")

      // Reset form
      setForm({
        fullName: "",
        email: "",
        position: "",
        partnerId: null,
        isSalesman: false,
        remarks: "",
      })
      setModuleAccess({})
      setTab("profile")
    } catch (err) {
      console.error("Error creating user:", err)
      setError(err.message || "Failed to create user")
    } finally {
      setLoading(false)
    }
  }

  // Helper function to display partner name with company info
  const getPartnerDisplayName = (partner) => {
    // For non-company partners, show only partner name
    return partner.name
  }

  return (
    <form onSubmit={onSubmit}>
      {/* Error Message Display */}
      {error && (
        <div className="alert alert-danger alert-dismissible fade show" role="alert">
          {error}
          <button type="button" className="btn-close" onClick={() => setError(null)}></button>
        </div>
      )}

      {/* tabs (keep classes names from HTML) */}
      <ul className="nav nav-tabs" id="userTabs" role="tablist">
        <li className="nav-item" role="presentation">
          <button
            type="button"
            className={`nav-link ${tab === "profile" ? "active" : ""}`}
            onClick={() => setTab("profile")}
            role="tab"
            aria-selected={tab === "profile"}
          >
            User Profile
          </button>
        </li>
        <li className="nav-item" role="presentation">
          <button
            type="button"
            className={`nav-link ${tab === "access" ? "active" : ""}`}
            onClick={() => setTab("access")}
            role="tab"
            aria-selected={tab === "access"}
          >
            Module Access
          </button>
        </li>
      </ul>

      <div className="tab-content mt-3" id="userTabsContent">
        {/* PROFILE TAB */}
        <div className={`tab-pane fade ${tab === "profile" ? "show active" : ""}`} id="profile" role="tabpanel">
          <div className="row g-3">
            <div className="col-md-6">
              <label htmlFor="fullName" className="form-label">
                Full Name
              </label>
              <input
                type="text"
                id="fullName"
                name="fullName"
                className="form-control"
                placeholder="Full Name"
                value={form.fullName}
                onChange={onChange}
                required
              />
            </div>
            <div className="col-md-6">
              <label htmlFor="email" className="form-label">
                Email Address
              </label>
              <input
                type="email"
                id="email"
                name="email"
                className="form-control"
                placeholder="Email Address"
                value={form.email}
                onChange={onChange}
                required
              />
            </div>
            <div className="col-md-6">
              <label htmlFor="position" className="form-label">
                Position
              </label>
              <input
                type="text"
                id="position"
                name="position"
                className="form-control"
                placeholder="Position"
                value={form.position}
                onChange={onChange}
              />
            </div>

            <div className="col-md-6">
              <label htmlFor="partnerId" className="form-label">
                Partner Assignment
              </label>
              <select
                id="partnerId"
                name="partnerId"
                className="form-select"
                value={form.partnerId}
                onChange={onChange}
                disabled={partnersLoading}
              >
                <option value="">Select</option>
                {!partnersLoading && (
                  <>
                    <optgroup label="Company">
                      {partners.company && partners.company.length > 0 ? (
                        partners.company.map((partner) => (
                          <option key={partner._id} value="company">
                            {partner.parentCompany?.companyName || partner.companyName || partner.name}
                          </option>
                        ))
                      ) : (
                        <option value="" disabled>
                          No companies available
                        </option>
                      )}
                    </optgroup>

                    {partners.marine && partners.marine.length > 0 && (
                      <optgroup label="Marine">
                        {partners.marine.map((partner) => (
                          <option key={partner._id} value="marine">
                            {partner.name}
                          </option>
                        ))}
                      </optgroup>
                    )}

                    {partners.commercial && partners.commercial.length > 0 && (
                      <optgroup label="Commercial">
                        {partners.commercial.map((partner) => (
                          <option key={partner._id} value="commercial">
                            {partner.name}
                          </option>
                        ))}
                      </optgroup>
                    )}

                    {partners.selling && partners.selling.length > 0 && (
                      <optgroup label="Selling">
                        {partners.selling.map((partner) => (
                          <option key={partner._id} value="selling">
                            {partner.name}
                          </option>
                        ))}
                      </optgroup>
                    )}
                  </>
                )}
              </select>

              {/* agent info box (same classes) */}
              <div className={`agent-info ${layerInfo ? "" : "d-none"} mt-3`}>
                <div>
                  <strong>Agent Type:</strong> <span id="agentType">{layerInfo?.type}</span>
                </div>
                <div>
                  <strong>Organizational Layer:</strong> <span id="agentLayer">{layerInfo?.layer}</span>
                </div>
              </div>
            </div>

            <div className="col-md-6">
              <label className="form-label">Is Salesman</label>
              <div>
                <label
                  className="status-toggle"
                  style={{ position: "relative", display: "inline-block", width: 50, height: 24 }}
                >
                  <input
                    type="checkbox"
                    name="isSalesman"
                    checked={form.isSalesman}
                    onChange={onChange}
                    style={{ opacity: 0, width: 0, height: 0 }}
                  />
                  <span
                    className="slider"
                    style={{
                      position: "absolute",
                      cursor: "pointer",
                      inset: 0,
                      backgroundColor: form.isSalesman ? "#2575fc" : "#ccc",
                      transition: ".4s",
                      borderRadius: 24,
                    }}
                  />
                  <span
                    style={{
                      position: "absolute",
                      height: 16,
                      width: 16,
                      left: form.isSalesman ? 30 : 4,
                      bottom: 4,
                      backgroundColor: "#fff",
                      transition: ".4s",
                      borderRadius: "50%",
                    }}
                  />
                </label>
              </div>
            </div>

            <div className="col-md-12">
              <label htmlFor="remarks" className="form-label">
                Remarks
              </label>
              <textarea
                id="remarks"
                name="remarks"
                rows="3"
                className="form-control"
                placeholder="Additional remarks"
                value={form.remarks}
                onChange={onChange}
              />
            </div>
          </div>
        </div>

        {/* ACCESS TAB */}
        <div className={`tab-pane fade ${tab === "access" ? "show active" : ""}`} id="access" role="tabpanel">
          {!layerInfo ? (
            <div id="moduleAccessContainer" className="mt-3 text-center text-muted">
              <i className="bi bi-shield-lock fs-1 mb-3"></i>
              <p>Select a Partner Assignment in User Profile to configure Module Access</p>
            </div>
          ) : (
            <div className="table-responsive mt-2">
              <table className="table table-bordered">
                <thead>
                  <tr style={{ backgroundColor: "#001f4d", color: "#fff" }}>
                    <th style={{ color: "#fff" }}>Module</th>
                    <th style={{ color: "#fff" }}>Access Rights Group</th>
                  </tr>
                </thead>
                <tbody>
                  {modules.map((module) => {
                    const accessGroups = accessGroupsByModule[module.code] || []
                    const isLoading = accessGroupsLoading[module.code]

                    return (
                      <tr key={module.code}>
                        <td>{module.name}</td>
                        <td>
                          <select
                            className="form-select"
                            value={moduleAccess[module.code] || ""}
                            onChange={(e) => onSelectAccess(module.code, e.target.value)}
                            disabled={isLoading}
                          >
                            <option value="">{isLoading ? "Loading..." : "Select group"}</option>
                            {accessGroups.length > 0 ? (
                              accessGroups.map((group) => (
                                <option key={group._id} value={group._id}>
                                  {group.groupName}
                                </option>
                              ))
                            ) : (
                              <option value="" disabled>
                                {isLoading ? "Loading..." : "No Groups Available"}
                              </option>
                            )}
                          </select>
                        </td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      <button type="submit" className="btn btn-turquoise mt-4" disabled={loading}>
        {loading ? "Creating User..." : "Create User"}
      </button>
    </form>
  )
}
